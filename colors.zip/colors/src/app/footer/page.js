import { Box, Text, Button, Input, Flex, VStack, Image } from '@chakra-ui/react';
import React from 'react';

const Footer = () => {
    return (
        <>
            <Flex
                mt="50px"
                h="30vh"
                w="100vw"
                justifyContent="center"
                alignItems="center"
                textAlign="center"
            >
                <Text
                    color="black"
                    fontSize={{ base: "20px", sm: "35px", lg: "50px" }}
                    fontWeight="650"
                    w={{ base: "92vw", lg: "45vw" }}
                >
                    Loved by thousands of creators and brands
                </Text>
            </Flex>

            <Flex
                width="100vw"
                minH="100vh"
                gap="50px"
                p="30px"
                overflowX="scroll"
                sx={{
                    '&::-webkit-scrollbar': {
                        display: 'none',
                    },
                }}
                align="flex-start"
                cursor="pointer"
            >
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (1).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (2).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (3).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (4).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (5).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (6).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (7).png" />
                <Image boxShadow="dark-lg" borderRadius="10px" src="s1 (8).png" />
            </Flex>

            <Box
                h="80vh"
                bg="#506cf0"
                w="100vw"
                display="flex"
                justifyContent="center"
                gap="10px"
                flexDir="column"
                alignItems="center"
            >
                <Text
                    px="20px"
                    fontSize={{ base: "25px", sm: "35px", lg: "55px" }}
                    fontWeight="700"
                    mb="50px"
                    color="white"
                >
                    Ready to get started?
                </Text>

                <Flex
                    display={{ base: "none", sm: "flex" }}
                    w={{ base: "0px", sm: "475px", md: "600px" }}
                    justify="center"
                    h={{ base: "0px", sm: "70px" }}
                    bg="white"
                    borderRadius="10px"
                    align="center"
                    textAlign="center"
                    gap={{sm:"40px",md:"0px"}}
                >
                    <Input
                        color="black"
                        ml={{ base: "5px", sm: "20px", md: "40px" }}
                        type="text"
                        w={{ base: "200px", sm: "200px", md: "300px" }}
                        variant="unstyled"
                        fontSize="18px"
                        fontWeight="500"
                        _placeholder={{ color: "#42464d" }}
                        placeholder="Enter your email address"
                    />
                    <Button
                        type="submit"
                        color="white"
                        bgGradient="linear(to-tl, #471aff 40% ,  #aec5f9)"
                        _hover={{ bgGradient: 'linear(to-br, #471aff 40% ,  #aec5f9)' }}
                        width={{ base: "200px", sm: "200px",md:"250px" }}
                        h={{ base: "50px", sm: "60px" }}
                    >
                        Start your 14-day free trial
                    </Button>
                </Flex>
                <Flex  gap="20px" display={{ base: "flex", sm: "none" }} flexDir="column">
                    <Input
                        color="black"

                        pl="40px"
                        bg="white"
                        h="60px"
                        type="text"
                        w="90vw"
                        variant="unstyled"
                        fontSize="18px"
                        fontWeight="500"
                        _placeholder={{ color: "#42464d" }}
                        placeholder="Enter your email address"
                    />

                    <Button
                        type="submit"
                        color="white"

                        bgGradient="linear(to-tl, #471aff 40% ,  #aec5f9)"
                        _hover={{ bgGradient: 'linear(to-br, #471aff 40% ,  #aec5f9)' }}
                        width="90vw"
                        h="60px"
                    >
                        Start your 14-day free trial
                    </Button>
                </Flex>
                <Text color="white">Try Circle free. No credit card required.</Text>
            </Box>

            <Box h="100vh" w="100vw"></Box>
        </>
    );
};

export default Footer;